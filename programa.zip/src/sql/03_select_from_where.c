#include <stdbool.h>
#include <stdio.h>

#include "../../include/IO.h"
#include "../../include/data_header.h"
#include "../../include/data_record.h"
#include "../../include/filtro.h"
#include "../../include/sql_functions.h"

// Função auxiliar para evitar repetição quando há falha no
// processamento. Libera a memória de arquivos, cabeçalhos e registros de filtro
// alocados.
void file_processing_failure_where(FILE **f_bin, DataHeader **header,
                                   DataRecord **filter) {
  if (f_bin != NULL && *f_bin != NULL) {
    fclose(*f_bin);
    *f_bin = NULL;
  }
  if (header != NULL) {
    data_header_destroy(header);
  }
  if (filter != NULL) {
    data_record_destroy(filter);
  }

  printf("Falha no processamento do arquivo.\n");
}

// Itera pelos registros do arquivo binário e imprime aqueles que passam
// pelo filtro.
bool search(FILE *f_bin, DataHeader *header, bool *search_for,
            DataRecord *filter) {
  if (f_bin == NULL || header == NULL || search_for == NULL || filter == NULL)
    return false;

  // Instancia um registro auxiliar para ler os dados do disco
  DataRecord *record = data_record_create();
  if (record == NULL)
    return false;

  bool found = false;

  // Pula o cabeçalho e vai para o primeiro Registro
  fseek(f_bin, HEADER_SIZE, SEEK_SET);

  int max_records = data_header_get_proxRRN(header);

  // Itera pelos registros do .bin
  for (int rrn = 0; rrn < max_records; rrn++) {
    // Lê o registro do arquivo binário
    if (!data_record_read(f_bin, record)) {
      break;
    }

    // Se o registro está removido, ele não é selecionado
    if (data_record_get_removido(record) == '1')
      continue;

    // Se o registro passa pelo filtro, ele é impresso
    if (match_filter(record, search_for, filter)) {
      found = true;
      display_data_record(record);

      // Se achou pelo codEstacao (chave única), pode parar a busca
      if (search_for[COD_ESTACAO])
        break;
    }
  }

  // Libera o registro auxiliar utilizado na leitura
  data_record_destroy(&record);

  return found;
}

// Executa a funcionalidade equivalente a um "SELECT ... WHERE" em SQL.
void select_from_where() {
  FILE *f_bin = NULL;
  DataHeader *header = NULL;
  DataRecord *filter = NULL;

  // Lê o nome do arquivo binário
  char bin_name[50];
  if (scanf("%s", bin_name) != 1) {
    file_processing_failure_where(&f_bin, &header, &filter);
    return;
  }

  // Abre o arquivo .bin para leitura e verifica consistência
  f_bin = open_binary_file(bin_name, "rb");
  if (f_bin == NULL) {
    return; // open_binary_file já lida com a mensagem e o close
  }

  // Cria a struct do cabeçalho lendo do arquivo binário
  header = data_header_create();
  if (header == NULL || !data_header_read(f_bin, header)) {
    file_processing_failure_where(&f_bin, &header, &filter);
    return;
  }

  // Lê o número de consultas a serem feitas
  int num_queries;
  if (scanf("%d", &num_queries) != 1) {
    file_processing_failure_where(&f_bin, &header, &filter);
    return;
  }

  // Itera sobre as consultas
  for (int i = 0; i < num_queries; i++) {
    // Instancia o registro que serve como comparação para filtrar os dados
    filter = data_record_create();
    if (filter == NULL) {
      file_processing_failure_where(&f_bin, &header, &filter);
      return;
    }

    // Array auxiliar para informar quais campos devem ser comparados com o
    // filtro
    bool search_for[PUBLIC_FIELDS];

    // Preenche a struct filter com os valores do filtro de pesquisa
    filter_build(filter, search_for);

    bool found = search(f_bin, header, search_for, filter);

    // Se nenhum registro foi encontrado, o usuário é avisado
    if (!found) {
      printf("Registro inexistente.\n");
    }

    // Separa as consultas por uma linha em branco
    printf("\n");

    // Destrói o filtro após usá-lo na iteração atual para evitar memory leak
    data_record_destroy(&filter);
  }

  // Libera a memória final
  fclose(f_bin);
  data_header_destroy(&header);
}
