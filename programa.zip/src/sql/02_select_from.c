#include <stdbool.h>
#include <stdio.h>

#include "../../include/IO.h"
#include "../../include/data_header.h"
#include "../../include/data_record.h"
#include "../../include/sql_functions.h"

// Função auxiliar para evitar repetição de código quando há falha no
// processamento. Libera a memória alocada e fecha arquivos abertos antes de
// exibir a mensagem de erro.
void file_processing_failure_select(FILE **f_bin, DataHeader **header,
                                    DataRecord **record) {
  if (f_bin != NULL && *f_bin != NULL) {
    fclose(*f_bin);
    *f_bin = NULL;
  }
  if (header != NULL) {
    data_header_destroy(header);
  }
  if (record != NULL) {
    data_record_destroy(record);
  }

  printf("Falha no processamento do arquivo.\n");
}

// Executa a funcionalidade equivalente a um "SELECT *" em SQL.
// Lê todos os registros de um arquivo binário e imprime os que não estão
// logicamente removidos.
void select_from() {
  FILE *f_bin = NULL;
  DataHeader *header = NULL;
  DataRecord *record = NULL;

  // Lê o nome do arquivo binário
  char bin_name[50];
  if (scanf("%s", bin_name) != 1) {
    file_processing_failure_select(&f_bin, &header, &record);
    printf("Nome\n");
    return;
  }

  // Abre o arquivo .bin para leitura e verifica se a abertura
  // foi bem sucedida conferindo o status do arquivo
  f_bin = open_binary_file(bin_name, "rb");
  if (f_bin == NULL) {
    printf("f_bin NULL\n");
    // open_binary_file já imprime a mensagem de erro e lida com o close, então
    // apenas encerramos
    return;
  }

  // Instancia e cria a estrutura do cabeçalho lendo do arquivo binário
  header = data_header_create();
  if (header == NULL || !data_header_read(f_bin, header)) {
    file_processing_failure_select(&f_bin, &header, &record);
    printf("Header\n");
    return;
  }

  // Instancia o registro auxiliar que será usado iterativamente para ler o .bin
  record = data_record_create();
  if (record == NULL) {
    file_processing_failure_select(&f_bin, &header, &record);
    printf("Record\n");
    return;
  }

  // Flag para indicar se algum registro foi encontrado e exibido
  bool found = false;

  // Pular para o primeiro registro físico (após o cabeçalho)
  fseek(f_bin, HEADER_SIZE, SEEK_SET);

  // Itera por todos os registros previstos no arquivo binário
  int total_records = data_header_get_proxRRN(header);
  for (int rrn = 0; rrn < total_records; rrn++) {

    // Lê o registro do .bin para a estrutura do TAD
    if (!data_record_read(f_bin, record)) {
      file_processing_failure_select(&f_bin, &header, &record);
      printf("Record read\n");
      return;
    }

    // O registro só é impresso se não estiver marcado como removido
    if (data_record_get_removido(record) == '0') {
      found = true;
      display_data_record(record);
    }
  }

  // Se nenhum registro for encontrado (arquivo apenas com removidos), o usuário
  // é avisado
  if (!found) {
    printf("Registro inexistente.\n");
  }

  // Fecha o arquivo e libera a memória alocada do heap
  fclose(f_bin);
  data_header_destroy(&header);
  data_record_destroy(&record);
}
